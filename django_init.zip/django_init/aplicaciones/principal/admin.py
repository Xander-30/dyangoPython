from django.contrib import admin
# Register your models here.
from .models import Persona
# se registra en la pagina de admin.
admin.site.register(Persona)


