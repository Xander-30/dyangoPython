from django.apps import AppConfig


class PrincipalConfig(AppConfig):
    name = 'principal'
